#include "Arduino.h"
#include "DFR_Key.h"

#define DEFAULT_KEY_PIN 0; 
#define DEFAULT_THRESHOLD 50;

// static int RIGHTKEY_ARV = 0;
// static int UPKEY_ARV = 144; //that's read "analog read value"
// static int DOWNKEY_ARV = 329;
// static int LEFTKEY_ARV = 505;
// static int SELKEY_ARV = 742;
// static int NOKEY_ARV = 1023;
#define RIGHTKEY_ARV 50
#define UPKEY_ARV    250
#define DOWNKEY_ARV  450
#define LEFTKEY_ARV  650
#define SELKEY_ARV   850
#define NOKEY_ARV    1023

//Analog value read has to be the same (within tolerance) in two sampling points set '_refreshRate' milliseconds apart

DFR_Key::DFR_Key(int analog_pin)
{
    _refreshRate = 20;
    _keyPin      = analog_pin;
    _threshold   = DEFAULT_THRESHOLD;
    _curInput    = NO_KEY;
    _tempKey     = NO_KEY;
    _curKey      = NO_KEY;
    _oldTime     = 0;
    _debouncing  = false;
}

int DFR_Key::getKey()
{
    if (_debouncing && (millis() > _oldTime + _refreshRate))
    {
        _curInput = analogRead(_keyPin);
        _debouncing = false;
        
        //Detect Key
        if      (_curInput < UPKEY_ARV)     _tempKey = UP_KEY;
        else if (_curInput < DOWNKEY_ARV)   _tempKey = DOWN_KEY;
        else if (_curInput < RIGHTKEY_ARV)  _tempKey = RIGHT_KEY;
        else if (_curInput < LEFTKEY_ARV)   _tempKey = LEFT_KEY;
        else if (_curInput < SELKEY_ARV)    _tempKey = SELECT_KEY;
        else                                _tempKey = NO_KEY;
        
        //Have to read the same key twice
        if (_curKey == _tempKey )
        {
            //Debouncing succeeded
            return _curKey;
        }
        
        //Key debouncing failed, value changed in debouncing time
        return SAMPLE_WAIT;
        
    }
    else if (!_debouncing)
    {
        _debouncing = true;
         
        _curInput = analogRead(_keyPin);
         
        //Detect Key
        if      (_curInput < UPKEY_ARV)     _curKey = UP_KEY;
        else if (_curInput < DOWNKEY_ARV)   _curKey = DOWN_KEY;
        else if (_curInput < RIGHTKEY_ARV)  _curKey = RIGHT_KEY;
        else if (_curInput < LEFTKEY_ARV)   _curKey = LEFT_KEY;
        else if (_curInput < SELKEY_ARV)    _curKey = SELECT_KEY;
        else                                _curKey = NO_KEY;
        
        _oldTime = millis();
    }
    return SAMPLE_WAIT;
}

void DFR_Key::setRate(int rate)
{
  _refreshRate = rate;
}